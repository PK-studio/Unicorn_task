$(document).ready(function(){
    var pages =[
        {"pageNumber": "1",
         "question": "As an underwriter at Lloyd’s, I have been offered the opportunity to renew an expiring aviation risk that has had no claims in the past three years. I am keen to renew, however, the market is softening, and the broker believes that he can get better terms elsewhere in the market.",
         "answer1":"Offer the broker a personal incentive to place the business with you.",
         "answer2":"Insist on a renewal on last year’s terms and tell the broker to absorb any premium reduction from his commission.",
         "answer3":"Remind the broker of the benefits, for the client, of renewing with an established underwriter with great claims service standards.",
         "answer4":"Accept a rate reduction but only if the broker takes you for dinner at your favourite restaurant.",
         "correctanswer":"3"},
        {"pageNumber": "2",
         "question": "Page No 2",
         "answer1":"Page No 2",
         "answer2":"Page No 2",
         "answer3":"Page No 2",
         "answer4":"Page No 2",
         "correctanswer":"Page No 2"}
    ]
    pageNo = 0;
    function loadpage(){
        var page = pages[pageNo];
        $("#question").html(page.question)
        $("#1 p").html(page.answer1)
        $("#2 p").html(page.answer2)
        $("#3 p").html(page.answer3)
        $("#4 p").html(page.answer4)
    }
    loadpage()
    $(".next").on('click', function(){
        $(".testpanel").animate({height: '0px', opacity: '0'}).html("");
        $('footer').children().removeClass('activefooter');
        $('.content').css('pointer-events', 'inherit');
        $('.testsubmit').removeClass('active');
        $('.answer').children('.tickbox').removeClass('ticked');
        pageNo ++
        loadpage()
    });
});